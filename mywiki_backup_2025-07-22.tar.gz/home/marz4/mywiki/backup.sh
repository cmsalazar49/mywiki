#!/bin/bash
tar -czvf mywiki_backup_$(date +%F).tar.gz ~/mywiki
