# Linux Basics
- pwd: show current directory
- ls: list file
- cd: change directory
